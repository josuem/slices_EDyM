//
// Temporary compatibility file for renaming of this file to util/StyleList.ts
// (to be removed in the next release)
//
export * from '../../util/StyleList.js';

