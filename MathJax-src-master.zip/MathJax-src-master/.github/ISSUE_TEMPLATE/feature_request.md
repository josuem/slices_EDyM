---
name: Feature request
about: Suggest an idea for MathJax
title: ''
labels: ''
assignees: ''

---

Please submit MathJax feature requests at

https://github.com/mathjax/MathJax/issues

unless they are about structural issues in this repository (e.g., the package.json file, the compilation process, the repository layout, etc).  New features for MathJax should be requested at the link above.

If you are not part of the MathJax team, it is unlikely that you should be posting an issue here.  Use the tracker linked above instead.
