import './lib/tagformat.js';
import {rename} from '../rename.js';

rename('tagFormat', 'tagformat', true);
