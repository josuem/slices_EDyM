import './lib/amscd.js';
import {rename} from '../rename.js';

rename('amsCd', 'amscd', true);
