import {FontData} from '../../../../js/output/svg/FontData.js';

export class TeXFont extends FontData {};

TeXFont.OPTIONS = {fontURL: '.'};
