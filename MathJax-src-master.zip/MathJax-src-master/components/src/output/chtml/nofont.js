import {FontData} from '../../../../js/output/chtml/FontData.js';

export class TeXFont extends FontData {};

TeXFont.OPTIONS = {fontURL: '.'};
