import './lib/assistive-mml.js';

import {AssistiveMmlHandler} from '../../../../js/a11y/assistive-mml.js';

if (MathJax.startup) {
  MathJax.startup.extendHandler(handler => AssistiveMmlHandler(handler));
}
