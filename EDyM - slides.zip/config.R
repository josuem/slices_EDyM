options(htmltools.dir.version = FALSE)
library(knitr)
library(tidyverse)
library(xaringanExtra)
library(icons)
# set default options
opts_chunk$set(echo=FALSE,
               collapse = TRUE,
               fig.width = 7.252,
               fig.height = 4,
               dpi = 300)

knitr::opts_chunk$set(echo = FALSE, 
                      fig.align = "center",
                      dev = "svg")
# set engines
knitr::knit_engines$set("markdown")

xaringanExtra::use_tile_view()
xaringanExtra::use_panelset()
xaringanExtra::use_scribble()
xaringanExtra::use_tachyons()
xaringanExtra::use_extra_styles(
  hover_code_line = TRUE,         #<<
  mute_unhighlighted_code = TRUE  #<<
)

# xaringanExtra::use_share_again()

todo <- FALSE
n_ej <- 1

eps2png <- function(file){
  command <- paste("gswin64c -dBATCH -dNOPAUSE -dQUIET -sDEVICE=pdfwrite -dEPSCrop -r900x900 -sDEVICE=pngalpha -o ", file, ".png ", file, ".eps", sep="")
  system(command)
}
