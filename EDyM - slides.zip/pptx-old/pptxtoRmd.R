# Transform pptx to rmarkdown file
library(slidex)
setwd("D:/drive/EDyM - slides/pptx-old")
convert_pptx(path="02 Conceptos de Lógicas Digital.pptx", author="Josué")
