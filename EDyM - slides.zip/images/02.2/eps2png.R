if(!file.exists("D:/drive/EDyM - slides/images/02.2/data")){
  dir.create("D:/drive/EDyM - slides/images/02.2/data.png")
}

